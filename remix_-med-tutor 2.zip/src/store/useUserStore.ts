import { useState, useEffect } from 'react';
import { db, OperationType, handleFirestoreError } from '../lib/firebase';
import { doc, setDoc, getDoc, collection, query, orderBy, onSnapshot, limit } from 'firebase/firestore';

export interface PastLecture {
  id: string;
  uid?: string;
  title: string;
  summary: string;
  date: number;
  analysis?: any;
}

export type Dialect = 'Iraqi' | 'Moslawi' | 'Egyptian' | 'Maghrebi' | 'Syrian' | 'Gulf' | 'Palestinian' | 'Kurdish' | 'Fusha' | 'English';

export interface UserStats {
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  pastLectures: PastLecture[];
  dialect: Dialect;
  subscription: 'free' | 'paid';
  freeUploadsUsed: number;
  totalQuizzes?: number;
  averageScore?: number;
}

const DEFAULT_STATS: UserStats = {
  level: 'Beginner',
  pastLectures: [],
  dialect: 'Iraqi',
  subscription: 'free',
  freeUploadsUsed: 0,
  totalQuizzes: 0,
  averageScore: 0
};

export function useUserStore(userId?: string) {
  const getStorageKey = (uid?: string) => uid ? `med_student_stats_${uid}` : 'med_student_stats';

  const [stats, setStats] = useState<UserStats>(() => {
    const saved = localStorage.getItem(getStorageKey(userId));
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...DEFAULT_STATS, ...parsed };
      } catch (e) {
        console.error('Failed to parse stats from local storage', e);
      }
    }
    return DEFAULT_STATS;
  });

  // Fetch/Sync from Firestore
  useEffect(() => {
    if (!userId) {
      setStats(prev => {
        const saved = localStorage.getItem(getStorageKey());
        if (saved) {
          try {
            return { ...DEFAULT_STATS, ...JSON.parse(saved) };
          } catch (e) {}
        }
        return DEFAULT_STATS;
      });
      return;
    }

    // 1. Sync User Profile
    const userRef = doc(db, 'users', userId);
    const unsubscribeUser = onSnapshot(userRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as UserStats;
        setStats(prev => ({
          ...prev,
          level: data.level || prev.level,
          dialect: data.dialect || prev.dialect,
          subscription: data.subscription || prev.subscription,
          freeUploadsUsed: data.freeUploadsUsed ?? prev.freeUploadsUsed,
          totalQuizzes: data.totalQuizzes ?? prev.totalQuizzes,
          averageScore: data.averageScore ?? prev.averageScore
        }));
      }
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${userId}`);
    });

    // 2. Sync Lectures
    const lecturesRef = collection(db, 'users', userId, 'lectures');
    const q = query(lecturesRef, orderBy('date', 'desc'), limit(50));
    const unsubscribeLectures = onSnapshot(q, (snapshot) => {
      const lectures: PastLecture[] = [];
      snapshot.forEach(doc => {
        lectures.push(doc.data() as PastLecture);
      });
      setStats(prev => ({ ...prev, pastLectures: lectures }));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `users/${userId}/lectures`);
    });

    return () => {
      unsubscribeUser();
      unsubscribeLectures();
    };
  }, [userId]);

  // Save to Local Storage as backup
  useEffect(() => {
    try {
      localStorage.setItem(getStorageKey(userId), JSON.stringify(stats));
    } catch (e) {
      console.warn('Failed to save stats to local storage', e);
    }
  }, [stats, userId]);

  const addPastLecture = async (lecture: PastLecture) => {
    if (userId) {
      try {
        const lectureCopy = { ...lecture, uid: userId };
        const lectureRef = doc(db, 'users', userId, 'lectures', lecture.id);
        await setDoc(lectureRef, lectureCopy);
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `users/${userId}/lectures/${lecture.id}`);
      }
    } else {
      setStats((prev) => ({
        ...prev,
        pastLectures: [lecture, ...(Array.isArray(prev.pastLectures) ? prev.pastLectures : [])],
      }));
    }
  };

  const setDialect = async (dialect: Dialect) => {
    if (userId) {
      try {
        const userRef = doc(db, 'users', userId);
        await setDoc(userRef, { dialect }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
      }
    } else {
      setStats((prev) => ({ ...prev, dialect }));
    }
  };

  const incrementFreeUploads = async () => {
    const newVal = (stats.freeUploadsUsed || 0) + 1;
    if (userId) {
      try {
        const userRef = doc(db, 'users', userId);
        await setDoc(userRef, { freeUploadsUsed: newVal }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
      }
    } else {
      setStats((prev) => ({ ...prev, freeUploadsUsed: newVal }));
    }
  };

  const upgradeSubscription = async () => {
    if (userId) {
      try {
        const userRef = doc(db, 'users', userId);
        await setDoc(userRef, { subscription: 'paid' }, { merge: true });
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
      }
    } else {
      setStats((prev) => ({ ...prev, subscription: 'paid' }));
    }
  };

  return { stats, addPastLecture, setDialect, incrementFreeUploads, upgradeSubscription };
}
